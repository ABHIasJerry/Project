const int BUZZER_PIN = 25;
const int INPUT_PIN = 2; // Automatic trigger pin

// Volatile variables are mandatory for hardware interrupts
volatile bool alertTriggered = false;
volatile unsigned long lastInterruptTime = 0;

int currentAlertMode = 1; // Tracks which alert to play next

void IRAM_ATTR handlePinTrigger() {
  unsigned long interruptTime = millis();
  // Software debouncing: Ignore spikes faster than 250ms
  if (interruptTime - lastInterruptTime > 250) {
    alertTriggered = true;
    lastInterruptTime = interruptTime;
  }
}

void setup() {
  Serial.begin(115200);

  // HARDCODED: Replaced variable with '8'-bit resolution directly in the parameter
  ledcAttachChannel(BUZZER_PIN, 1000, 8, 0);

  // Configure Pin 8 with an internal pull-up resistor
  pinMode(INPUT_PIN, INPUT_PULLUP);
  
  // Attach interrupt to Pin 8: Triggers instantly when pulled to GND (FALLING edge)
  attachInterrupt(digitalPinToInterrupt(INPUT_PIN), handlePinTrigger, FALLING);

  Serial.println("\n=== Automatic Interrupt Alarm Dashboard Ready ===");
  Serial.println("--> Ground GPIO 2[esp pin 24] to instantly cycle through the alert sounds!");
}

void loop() {
  // Check if Pin 8 detected an automatic trigger event
  if (alertTriggered) {
    alertTriggered = false; // Reset flag instantly
    executeNextAlert();
  }
}

void executeNextAlert() {
  switch (currentAlertMode) {
    case 1:
      Serial.println("⚠️ INPUT DETECTED: Playing Autopilot Disengage...");
      for (int i = 0; i < 3; i++) {
        ledcWriteTone(BUZZER_PIN, 450);  delay(250);
        ledcWriteTone(BUZZER_PIN, 630);  delay(250);
      }
      break;

    case 2:
      Serial.println("⚠️ INPUT DETECTED: Playing Master Caution...");
      ledcWriteTone(BUZZER_PIN, 550);  delay(400);
      break;

    case 3:
      Serial.println("⚠️ INPUT DETECTED: Playing Master Warning Bell...");
      for (int i = 0; i < 3; i++) {
        ledcWriteTone(BUZZER_PIN, 800);  delay(120);
        silenceBuzzer();                 delay(60);
        ledcWriteTone(BUZZER_PIN, 800);  delay(120);
        silenceBuzzer();                 delay(60);
        ledcWriteTone(BUZZER_PIN, 800);  delay(120);
        silenceBuzzer();                 delay(400);
      }
      break;

    case 4:
      Serial.println("⚠️ INPUT DETECTED: Playing Cabin Call Chime...");
      ledcWriteTone(BUZZER_PIN, 550);  delay(350);
      ledcWriteTone(BUZZER_PIN, 440);  delay(500);
      break;

    case 5:
      Serial.println("⚠️ INPUT DETECTED: Playing Overspeed Clacker...");
      for (int i = 0; i < 8; i++) {
        ledcWriteTone(BUZZER_PIN, 800);  delay(80);
        ledcWriteTone(BUZZER_PIN, 400);  delay(80);
      }
      break;
  }

  silenceBuzzer();
  
  // Cycle to the next alert index layout for the subsequent press
  currentAlertMode++;
  if (currentAlertMode > 5) currentAlertMode = 1; 
}

void silenceBuzzer() {
  ledcWrite(BUZZER_PIN, 0);
}