// REMOTE CONTROL
#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>

// --- HARDWARE CONFIG ---
#define JOY_X_PIN 34
#define JOY_Y_PIN 35
#define BUTTON_PIN 14

// --- TARGET MAC ADDRESS (Replace with your Drone's ESP32 MAC Address) ---
uint8_t droneMacAddress[] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF}; 

// --- DATA STRUCTURES ---
// Struct sent from Controller -> Drone
typedef struct struct_control_signals {
  int16_t throttle;
  int16_t yaw;
  int16_t pitch;
  int16_t roll;
  bool auxButton;
} struct_control_signals;

// Struct received from Drone -> Controller
typedef struct struct_telemetry_data {
  float voltage;
  float current;
  int16_t rssi;
  int16_t satellites;
  float alt;
  double latitude;
  double longitude;
} struct_telemetry_data;

struct_control_signals controlPacket;
struct_telemetry_data telemetryPacket;

esp_now_peer_info_t peerInfo;

// --- CALLBACKS ---
// Executed when control data is sent out
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  // Serial.print("\r\nLast Packet Send Status:\t");
  // Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

// Executed when telemetry data arrives from the drone
void OnDataRecv(const esp_now_recv_info* recvInfo, const uint8_t *incomingData, int len) {
  memcpy(&telemetryPacket, incomingData, sizeof(telemetryPacket));
  
  Serial.println("\n--- TELEMETRY RECEIVED ---");
  Serial.printf("Volt: %.2fV | Alt: %.1fm | Sats: %d\n", telemetryPacket.voltage, telemetryPacket.alt, telemetryPacket.satellites);
  Serial.printf("GPS: %.6f, %.6f\n", telemetryPacket.latitude, telemetryPacket.longitude);
}

void setup() {
  Serial.begin(115200);
  
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  // Set device as a Wi-Fi Station
  WiFi.mode(WIFI_STA);

  // Initialize ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Register callback functions
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);
  
  // Register drone peer
  memcpy(peerInfo.peer_addr, droneMacAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
}

void loop() {
  // Read joystick input values (Mapped to standard RC pulse width ranges 1000 - 2000ms)
  controlPacket.throttle = map(analogRead(JOY_X_PIN), 0, 4095, 1000, 2000);
  controlPacket.yaw      = map(analogRead(JOY_Y_PIN), 0, 4095, 1000, 2000);
  controlPacket.pitch    = 1500; // Centered default if unassigned
  controlPacket.roll     = 1500; // Centered default if unassigned
  controlPacket.auxButton = (digitalRead(BUTTON_PIN) == LOW);

  // Send control signals packet over ESP-NOW to drone
  esp_err_t result = esp_now_send(droneMacAddress, (uint8_t *) &controlPacket, sizeof(controlPacket));
  
  if (result != ESP_OK) {
    Serial.println("Transmission Error");
  }

  // Control loop tick frequency (50Hz updates for robust flight control loops)
  delay(20); 
}

///////////////////////////////////////////////////////////////////////////////////////////////

// drone transmitter

#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>

// --- TARGET MAC ADDRESS (Replace with your Controller's ESP32 MAC Address) ---
uint8_t controllerMacAddress[] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};

// --- DATA STRUCTURES (Must match Controller perfectly) ---
typedef struct struct_control_signals {
  int16_t throttle;
  int16_t yaw;
  int16_t pitch;
  int16_t roll;
  bool auxButton;
} struct_control_signals;

typedef struct struct_telemetry_data {
  float voltage;
  float current;
  int16_t rssi;
  int16_t satellites;
  float alt;
  double latitude;
  double longitude;
} struct_telemetry_data;

struct_control_signals controlPacket;
struct_telemetry_data telemetryPacket;

esp_now_peer_info_t peerInfo;
unsigned long lastTelemetryTx = 0;
const unsigned long telemetryInterval = 200; // Send telemetry back at 5Hz (every 200ms)

// --- CALLBACKS ---
// Executed when telemetry send attempt completes
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  // Telemetry loop confirm flag handling can go here
}

// Executed when Control commands arrive from the remote control
void OnDataRecv(const esp_now_recv_info* recvInfo, const uint8_t *incomingData, int len) {
  memcpy(&controlPacket, incomingData, sizeof(controlPacket));
  
  // Here you can inject controlPacket commands straight into your flight loop or MSP/Mavlink interface
  Serial.printf("RX CMD -> Thr: %d | Yaw: %d | Aux: %s\n", 
                controlPacket.throttle, 
                controlPacket.yaw, 
                controlPacket.auxButton ? "ON" : "OFF");
}

void setup() {
  Serial.begin(115200);
  
  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);
  
  // Register remote controller peer
  memcpy(peerInfo.peer_addr, controllerMacAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }

  // Populate fixed/mock telemetry values
  telemetryPacket.voltage = 16.4;
  telemetryPacket.current = 8.2;
  telemetryPacket.satellites = 12;
  telemetryPacket.latitude = 37.774929;
  telemetryPacket.longitude = -122.419418;
  telemetryPacket.alt = 0.0;
}

void loop() {
  unsigned long currentMillis = millis();

  // Simulate evolving sensory variables on the drone
  telemetryPacket.alt += 0.05; 
  telemetryPacket.voltage -= 0.001;

  // Asynchronous telemetry transmissions (Prevents blocking control command inputs reception)
  if (currentMillis - lastTelemetryTx >= telemetryInterval) {
    lastTelemetryTx = currentMillis;
    
    esp_err_t result = esp_now_send(controllerMacAddress, (uint8_t *) &telemetryPacket, sizeof(telemetryPacket));
    if (result != ESP_OK) {
      Serial.println("Telemetry Return Tx Failed");
    }
  }

  // Allow background OS ticks to breathe
  yield();
}