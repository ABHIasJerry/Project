#include <WiFi.h>
#include <WebServer.h>
#include <Update.h>

// Set up the ESP32's own Wi-Fi network credentials
const char* ap_ssid = "ESP32-QUAD-Control";
const char* ap_password = "12345678"; 

// --- CUSTOM IP CONFIGURATION ---
IPAddress local_IP(192, 168, 10, 1);  // Desired ESP32 IP Address
IPAddress gateway(192, 168, 10, 1);   // Usually the same as local_IP
IPAddress subnet(255, 255, 255, 0);  // Standard subnet mask
// -------------------------------

WebServer server(80);

#define ONBOARD_LED 2 

unsigned long previousMillis = 0;
const long interval = 500; 
bool ledState = LOW;

const char* otaIndexPage = 
"<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>"
"<style>body{font-family:Arial,sans-serif;text-align:center;background:#f4f4f9;padding:50px;}"
".card{background:white;padding:30px;border-radius:10px;box-shadow:0 4px 8px rgba(0,0,0,0.1);display:inline-block;max-width:400px;width:100%;}"
"h2{color:#333;}input[type=file]{margin:20px 0;width:100%;}"
"input[type=submit]{background:#28a745;color:white;border:none;padding:10px 20px;border-radius:5px;cursor:pointer;font-size:16px;width:100%;}"
"input[type=submit]:hover{background:#218838;}</style></head>"
"<body><div class='card'><h2>ESP32 QUAD MCU FOTA System</h2>"
"<p>v2.0 | Abhinaba Ghosh. Upload your new <strong>.bin</strong> firmware to flash.</p>"
"<form method='POST' action='/update' enctype='multipart/form-data'>"
"<input type='file' name='update' accept='.bin'><br>"
"<input type='submit' value='Upload & Flash'>"
"</form></div></body></html>";

void setup() {
  pinMode(ONBOARD_LED, OUTPUT);
  digitalWrite(ONBOARD_LED, LOW);
  
  Serial.begin(115200);
  Serial.println("\nConfiguring Access Point...");

  WiFi.mode(WIFI_AP);

  // Apply the custom IP configuration BEFORE starting the Access Point
  if (!WiFi.softAPConfig(local_IP, gateway, subnet)) {
    Serial.println("AP Config Failed");
  }

  WiFi.softAP(ap_ssid, ap_password);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP Wi-Fi Network Created: ");
  Serial.println(ap_ssid);
  Serial.print("Go to this URL in your browser: http://");
  Serial.println(IP);

  // Route 1: Serve the web interface
  server.on("/", HTTP_GET, []() {
    server.sendHeader("Connection", "close");
    server.send(200, "text/html", otaIndexPage);
  });

  // Route 2: Handle binary upload
  server.on("/update", HTTP_POST, []() {
    server.sendHeader("Connection", "close");
    server.send(200, "text/plain", (Update.hasError()) ? "Update Failed!" : "Update Success! Rebooting chip...");
    delay(2000);
    ESP.restart();
  }, []() {
    HTTPUpload& upload = server.upload();
    if (upload.status == UPLOAD_FILE_START) {
      Serial.printf("Receiving firmware: %s\n", upload.filename.c_str());
      if (!Update.begin(UPDATE_SIZE_UNKNOWN)) { 
        Update.printError(Serial);
      }
    } else if (upload.status == UPLOAD_FILE_WRITE) {
      if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
        Update.printError(Serial);
      }
    } else if (upload.status == UPLOAD_FILE_END) {
      if (Update.end(true)) { 
        Serial.printf("Update complete: %u bytes.\n", upload.totalSize);
      } else {
        Update.printError(Serial);
      }
    }
  });

  server.begin();
}

void loop() {
  server.handleClient();

  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    ledState = !ledState; 
    digitalWrite(ONBOARD_LED, ledState);
  }
}