//////////////////////////////////////////
// vcc 3.3v
//ESP32 to GY-271 Honeywell HMC5883L
//GY-271 SCL -> ESP32 GPIO 22
//GY-271 SDA -> ESP32 GPIO 21
//////////////////////////////////////////

#include <Wire.h>

// I2C Addresses for both variations found on the GY-271 module
#define HMC5883L_ADDR 0x1E
#define QMC5883L_ADDR 0x0D

// Magnetic Declination for your specific location (in Radians)
// Find yours at http://www.magnetic-declination.com/
// Example: 1 Degree 25 Minutes = 1 + (25/60) = 1.416 Degrees = 0.0247 Radians
const float DECLINATION_ANGLE = 0.0247; 

uint8_t sensorAddress = 0x00;
bool isQMC = false;

// Calibration Offsets (Run a figure-8 calibration matrix to fill these out)
float targetOffsetX = 0.0;
float targetOffsetY = 0.0;
float targetOffsetZ = 0.0;

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22, 400000); // Initialize ESP32 I2C Fast Mode (400kHz)
  
  Serial.println("\n--- GY-271 Adaptive Diagnostic Suite ---");
  delay(1000);

  // 1. Scan and detect the specific chip variant
  Wire.beginTransmission(HMC5883L_ADDR);
  if (Wire.endTransmission() == 0) {
    sensorAddress = HMC5883L_ADDR;
    isQMC = false;
    Serial.println("Detected: Genuine Honeywell HMC5883L (0x1E)");
  } else {
    Wire.beginTransmission(QMC5883L_ADDR);
    if (Wire.endTransmission() == 0) {
      sensorAddress = QMC5883L_ADDR;
      isQMC = true;
      Serial.println("Detected: QMC5883L / Production authorized variant (0x0D)");
    }
  }

  if (sensorAddress == 0x00) {
    Serial.println("❌ ERROR: No GY-271 hardware sensor found on the I2C Bus!");
    while (1) delay(10);
  }

  // 2. Initialize the detected IC to maximum performance settings
  if (isQMC) {
    // QMC5883L configuration: Continuous mode, 200Hz ODR, 8G Range, 512 Oversampling
    Wire.beginTransmission(QMC5883L_ADDR);
    Wire.write(0x09); // Control Register 1
    Wire.write(0x0D | 0x0C | 0x00 | 0x01); // OSR:512, RNG:8G, ODR:200Hz, MODE:Continuous
    Wire.endTransmission();
    
    Wire.beginTransmission(QMC5883L_ADDR);
    Wire.write(0x0A); // Control Register 2
    Wire.write(0x00); // Disable soft reset / interrupts
    Wire.endTransmission();
  } else {
    // HMC5883L configuration: Continuous mode, 75Hz ODR, 1.3G Range
    Wire.beginTransmission(HMC5883L_ADDR);
    Wire.write(0x00); // Config Register A
    Wire.write(0x78); // 8 samples averaged, 75Hz data output rate
    Wire.endTransmission();

    Wire.beginTransmission(HMC5883L_ADDR);
    Wire.write(0x01); // Config Register B
    Wire.write(0x20); // Gain setting = 1.3 Gauss range (Standard)
    Wire.endTransmission();

    Wire.beginTransmission(HMC5883L_ADDR);
    Wire.write(0x02); // Mode Register
    Wire.write(0x00); // Continuous measurement mode
    Wire.endTransmission();
  }
  Serial.println("Sensor configuration locked at full execution capacity.");
}

void loop() {
  int16_t rawX, rawY, rawZ;
  float magX, magY, magZ;

  // 3. Extract processing data depending on chip register mappings
  if (isQMC) {
    Wire.beginTransmission(QMC5883L_ADDR);
    Wire.write(0x00); // Start at Data Output X LSB
    Wire.endTransmission(false);
    Wire.requestFrom(QMC5883L_ADDR, 6);

    if (Wire.available() >= 6) {
      rawX = Wire.read() | (Wire.read() << 8);
      rawY = Wire.read() | (Wire.read() << 8);
      rawZ = Wire.read() | (Wire.read() << 8);
    }
    // Scale factor for QMC5883L at 8G Range is ~3000 LSB/Gauss
    magX = (float)rawX / 3.0; 
    magY = (float)rawY / 3.0;
    magZ = (float)rawZ / 3.0;

  } else {
    Wire.beginTransmission(HMC5883L_ADDR);
    Wire.write(0x03); // Start at Data Output X MSB
    Wire.endTransmission(false);
    Wire.requestFrom(HMC5883L_ADDR, 6);

    if (Wire.available() >= 6) {
      rawX = (Wire.read() << 8) | Wire.read();
      rawZ = (Wire.read() << 8) | Wire.read(); // HMC orders Z before Y internally!
      rawY = (Wire.read() << 8) | Wire.read();
    }
    // Scale factor for HMC5883L at 1.3G Range is 1090 LSB/Gauss
    magX = (float)rawX * 0.92;
    magY = (float)rawY * 0.92;
    magZ = (float)rawZ * 0.92;
  }

  // 4. Apply hard-iron calibration adjustments
  float calX = magX - targetOffsetX;
  float calY = magY - targetOffsetY;
  float calZ = magZ - targetOffsetZ;

  // 5. Compute Compass Heading (assumes module is held flat/level)
  float heading = atan2(calY, calX);
  heading += DECLINATION_ANGLE;

  // Correct for directional wraps
  if (heading < 0) heading += 2 * PI;
  if (heading > 2 * PI) heading -= 2 * PI;

  float headingDegrees = heading * 180.0 / PI;

  // 6. Serial Telemetry Stream Output
  Serial.print("Mag_mG_X:");   Serial.print(calX, 1);       Serial.print(",");
  Serial.print("Mag_mG_Y:");   Serial.print(calY, 1);       Serial.print(",");
  Serial.print("Mag_mG_Z:");   Serial.print(calZ, 1);       Serial.print(",");
  Serial.print("Heading_Deg:"); Serial.println(headingDegrees, 1);

  delay(50); // High-frequency 20Hz update tracking frame
}