#include <TinyGPS++.h>

// The TinyGPS++ object
TinyGPSPlus gps;

// Use ESP32 Hardware Serial 2
HardwareSerial SerialGPS(2);

#define RXD2 16
#define TXD2 17
#define GPS_BAUDRATE 9600 // Default baud rate for most Neo-6M/8M modules

// Custom NMEA Parsers for Satellite Azimuth Array ($GPGSV message fields)
// Each $GPGSV sentence contains details for up to 4 satellites.
// We index fields manually to pull individual satellite Azimuths.
TinyGPSCustom sat1_azimuth(gps, "GPGSV", 6);  // Offset index for 1st sat azimuth
TinyGPSCustom sat2_azimuth(gps, "GPGSV", 10); // Offset index for 2nd sat azimuth
TinyGPSCustom sat3_azimuth(gps, "GPGSV", 14); // Offset index for 3rd sat azimuth
TinyGPSCustom sat4_azimuth(gps, "GPGSV", 18); // Offset index for 4th sat azimuth

unsigned long lastPrintTime = 0;
const unsigned long printInterval = 2000; // Print dashboard every 2 seconds

void setup() {
  Serial.begin(115200);
  
  // Initialize Hardware Serial 2 on specified pins
  SerialGPS.begin(GPS_BAUDRATE, SERIAL_8N1, RXD2, TXD2);

  Serial.println("\n--- Neo uBlox Master GPS Tracker Initialized ---");
  Serial.println("Waiting for Satellite Fix (Take module near a window)...");
}

void loop() {
  // Feed incoming data from hardware serial buffer to the GPS parser engine
  while (SerialGPS.available() > 0) {
    gps.encode(SerialGPS.read());
  }

  // Print data at the specified interval
  if (millis() - lastPrintTime >= printInterval) {
    lastPrintTime = millis();
    displayGPSDashboard();
  }
}

void displayGPSDashboard() {
  Serial.println("\n=================== GPS DATA TELEMETRY ===================");

  // 1. Fix Status & Satellites Tracked
  Serial.print("Fix Status: ");
  if (gps.location.isValid()) {
    Serial.print("FIXED | Satellites Tracked: ");
    Serial.println(gps.satellites.value());
  } else {
    Serial.print("NO FIX | Satellites in View: ");
    Serial.println(gps.satellites.value());
  }

  // 2. Latitude & Longitude
  Serial.print("Coordinates: ");
  if (gps.location.isValid()) {
    Serial.print(gps.location.lat(), 6);
    Serial.print(", ");
    Serial.println(gps.location.lng(), 6);
  } else {
    Serial.println("Waiting for coordinates...");
  }

  // 3. Altitude
  Serial.print("Altitude: ");
  if (gps.altitude.isValid()) {
    Serial.print(gps.altitude.meters(), 1);
    Serial.println(" meters");
  } else {
    Serial.println("N/A");
  }

  // 4. Speed & Heading Angle (Course)
  Serial.print("Speed: ");
  if (gps.speed.isValid()) {
    Serial.print(gps.speed.kmph(), 1);
    Serial.print(" km/h | Heading Angle: ");
    Serial.print(gps.course.deg(), 1);
    Serial.println("°");
  } else {
    Serial.println("N/A");
  }

  // 5. System Universal Coordinate Time (UTC)
  Serial.print("UTC Time: ");
  if (gps.date.isValid() && gps.time.isValid()) {
    char timeBuffer[32];
    // FIXED: Changed gps.time.min() to gps.time.minute()
    sprintf(timeBuffer, "%02d/%02d/%04d %02d:%02d:%02d UTC", 
            gps.date.month(), gps.date.day(), gps.date.year(),
            gps.time.hour(), gps.time.minute(), gps.time.second());
    Serial.println(timeBuffer);
  } else {
    Serial.println("Synchronizing Clock...");
  }

  // 6. Satellites Custom Azimuth Tracking 
  Serial.println("--- Current Satellite Azimuths ---");
  bool printedAzimuth = false;
  
  if (sat1_azimuth.isUpdated() && strlen(sat1_azimuth.value()) > 0) { Serial.printf(" SV1: %s° |", sat1_azimuth.value()); printedAzimuth = true; }
  if (sat2_azimuth.isUpdated() && strlen(sat2_azimuth.value()) > 0) { Serial.printf(" SV2: %s° |", sat2_azimuth.value()); printedAzimuth = true; }
  if (sat3_azimuth.isUpdated() && strlen(sat3_azimuth.value()) > 0) { Serial.printf(" SV3: %s° |", sat3_azimuth.value()); printedAzimuth = true; }
  if (sat4_azimuth.isUpdated() && strlen(sat4_azimuth.value()) > 0) { Serial.printf(" SV4: %s°", sat4_azimuth.value()); printedAzimuth = true; }
  
  if (!printedAzimuth) {
    Serial.println(" Processing GSV strings for satellite angles...");
  } else {
    Serial.println();
  }
  Serial.println("==========================================================");
}