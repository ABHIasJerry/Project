// Define ESP32 Pins for SMD LEDs
const int BEACON_RED_PIN = 4;
const int STROBE_WHITE_PIN = 23;

// Timing intervals (in milliseconds)
const unsigned long BEACON_INTERVAL = 1000; // Red beacon flashes once per second

// Non-blocking timer variables
unsigned long lastBeaconTime = 0;
unsigned long lastStrobeTime = 0;

// State tracking variables
bool beaconState = false;
int strobeStage = 0; 

void setup() {
  Serial.begin(115200);
  
  // Configure LED pins as outputs
  pinMode(BEACON_RED_PIN, OUTPUT);
  pinMode(STROBE_WHITE_PIN, OUTPUT);
  
  Serial.println("Aeroplane Navigation Beacon & Strobe System Initialized.");
}

void loop() {
  unsigned long currentMillis = millis();

  // ========================================================
  // 1. RED BEACON LIGHT: Steady Heartbeat Flash (1Hz)
  // ========================================================
  if (currentMillis - lastBeaconTime >= BEACON_INTERVAL) {
    lastBeaconTime = currentMillis;
    beaconState = !beaconState;
    digitalWrite(BEACON_RED_PIN, beaconState ? HIGH : LOW);
  }

  // ========================================================
  // 2. WHITE STROBE LIGHT: Aviation Double-Flash Pattern
  // ========================================================
  switch (strobeStage) {
    case 0: // Pause before the double flash
      if (currentMillis - lastStrobeTime >= 1200) { // 1.2 second silence
        digitalWrite(STROBE_WHITE_PIN, HIGH);      // First flash ON
        lastStrobeTime = currentMillis;
        strobeStage = 1;
      }
      break;

    case 1: // First flash duration
      if (currentMillis - lastStrobeTime >= 50) {   // ON for 50ms
        digitalWrite(STROBE_WHITE_PIN, LOW);       // First flash OFF
        lastStrobeTime = currentMillis;
        strobeStage = 2;
      }
      break;

    case 2: // Delay between the double flashes
      if (currentMillis - lastStrobeTime >= 80) {   // OFF for 80ms
        digitalWrite(STROBE_WHITE_PIN, HIGH);      // Second flash ON
        lastStrobeTime = currentMillis;
        strobeStage = 3;
      }
      break;

    case 3: // Second flash duration
      if (currentMillis - lastStrobeTime >= 50) {   // ON for 50ms
        digitalWrite(STROBE_WHITE_PIN, LOW);       // Second flash OFF
        lastStrobeTime = currentMillis;
        strobeStage = 0;                            // Reset back to main pause
      }
      break;
  }
}