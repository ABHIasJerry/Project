#include <Wire.h>
#include <VL53L0X.h>

VL53L0X sensor;

// --- Performance Profiles Selection ---
// Uncomment ONLY ONE of these to match your project needs
#define PERFORMANCE_PROFILE_HIGH_ACCURACY
//#define PERFORMANCE_PROFILE_HIGH_SPEED
//#define PERFORMANCE_PROFILE_LONG_RANGE

void setup() {
  Serial.begin(115200);
  
  // Initialize ESP32 I2C to Fast Mode (400kHz) on Pins 21 (SDA) and 22 (SCL)
  Wire.begin(21, 22, 400000);

  sensor.setBus(&Wire);
  if (!sensor.init()) {
    Serial.println("Failed to detect and initialize VL53L0X ToF sensor!");
    while (1) delay(10);
  }
  
  Serial.println("\n--- VL53L0X ToF Multi-Unit Tracker ---");

  // Load selected optimization profile
  #if defined(PERFORMANCE_PROFILE_HIGH_ACCURACY)
    sensor.setSignalRateLimit(0.1);
    sensor.setMeasurementTimingBudget(200000); // 200ms budget for high precision
    Serial.println("Profile: High Accuracy Mode");

  #elif defined(PERFORMANCE_PROFILE_HIGH_SPEED)
    sensor.setMeasurementTimingBudget(20000);  // 20ms budget for fast tracking (~50Hz)
    Serial.println("Profile: High Speed Mode");

  #elif defined(PERFORMANCE_PROFILE_LONG_RANGE)
    sensor.setSignalRateLimit(0.1);
    sensor.setMeasurementTimingBudget(33000);
    sensor.setVcselPulsePeriod(VL53L0X::VcselPeriodPreRange, 18);
    sensor.setVcselPulsePeriod(VL53L0X::VcselPeriodFinalRange, 14);
    Serial.println("Profile: Max Long Range Mode");
  #endif

  // Start continuous hardware background reading
  sensor.startContinuous();
}

void loop() {
  // 1. Read raw distance in millimeters from the hardware buffer
  uint16_t distance_mm = sensor.readRangeContinuousMillimeters();

  // 2. Check for timeouts or out-of-bounds metrics
  if (sensor.timeoutOccurred()) {
    Serial.println("TIMEOUT: Sensor hardware unresponsive!");
  } else if (distance_mm > 2000) {
    Serial.println("> Distance: Out of Max Range (>2 meters)");
  } else {
    
    // 3. Perform High-Precision Conversions
    float mm = (float)distance_mm;
    float cm = mm / 10.0;
    float feet = mm / 304.8; // 1 foot = 304.8 mm

    // 4. Output Data formatted for Serial Monitor / Serial Plotter
    Serial.print("</> Obstacle distance -> [mm] ->:"); Serial.print(mm, 1); Serial.print(",");
    Serial.print(" | [cm] ->:"); Serial.print(cm, 2); Serial.print(",");
    Serial.print(" | [feet] ->:"); Serial.println(feet, 3); // 3 decimal points for precision in feet
  }

  // The loop frequency is governed naturally by your timing budget profile configuration
}