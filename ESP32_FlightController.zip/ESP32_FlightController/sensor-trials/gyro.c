#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>

Adafruit_MPU6050 mpu;

// Calibration offsets
float gyroXoffset = 0.0, gyroYoffset = 0.0, gyroZoffset = 0.0;

// Orientation variables
float roll = 0.0;
float pitch = 0.0;
float yaw = 0.0; 

// Timing and Filter
unsigned long lastTime = 0;
const float alpha = 0.98; 

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22, 400000); // ESP32 I2C: Pins 21 (SDA), 22 (SCL) at 400kHz

  if (!mpu.begin()) {
    Serial.println("MPU6050 not found!");
    while (1) delay(10);
  }

  // Optimize sensor performance profiles
  mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  calibrateSensors();
  lastTime = micros();
}

void loop() {
  // 1. Calculate precise delta time (dt)
  unsigned long currentTime = micros();
  float dt = (currentTime - lastTime) / 1000000.0;
  lastTime = currentTime;

  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  // 2. Apply offsets and convert Gyro from rad/s to deg/s
  float gyroX = (g.gyro.x - gyroXoffset) * 180.0 / M_PI;
  float gyroY = (g.gyro.y - gyroYoffset) * 180.0 / M_PI;
  float gyroZ = (g.gyro.z - gyroZoffset) * 180.0 / M_PI;

  // 3. Calculate Roll & Pitch from Accelerometer vector
  float accelRoll  = atan2(a.acceleration.y, a.acceleration.z) * 180.0 / M_PI;
  float accelPitch = atan2(-a.acceleration.x, sqrt(a.acceleration.y * a.acceleration.y + a.acceleration.z * a.acceleration.z)) * 180.0 / M_PI;

  // 4. Complementary Filter Fusion
  roll  = alpha * (roll + gyroX * dt) + (1.0 - alpha) * accelRoll;
  pitch = alpha * (pitch + gyroY * dt) + (1.0 - alpha) * accelPitch;
  
  // 5. Yaw calculation (Pure Gyro Integration)
  yaw += gyroZ * dt; 
  
  // Keep Yaw constrained between -180 and +180 degrees
  if (yaw > 180.0) yaw -= 360.0;
  else if (yaw < -180.0) yaw += 360.0;

  // 6. Temperature Readings
  float tempC = temp.temperature;
  float tempF = (tempC * 9.0 / 5.0) + 32.0;

  // 7. Print to Serial Plotter / Monitor (Teleplot format compatible)
  Serial.print("</> Roll:"); Serial.print(roll); Serial.print(",");
  Serial.print(" | Pitch:"); Serial.print(pitch); Serial.print(",");
  Serial.print(" | Yaw:"); Serial.print(yaw); Serial.print(",");
  Serial.print(" | TempC:"); Serial.print(tempC); Serial.print(",");
  Serial.print(" | TempF:"); Serial.println(tempF);

  delay(10); // ~100Hz refresh rate
}

void calibrateSensors() {
  Serial.println("Calibrating... Keep IMU dead still.");
  delay(1000);
  int samples = 400;
  float x = 0, y = 0, z = 0;
  sensors_event_t a, g, temp;

  for (int i = 0; i < samples; i++) {
    mpu.getEvent(&a, &g, &temp);
    x += g.gyro.x;
    y += g.gyro.y;
    z += g.gyro.z;
    delay(3);
  }
  gyroXoffset = x / samples;
  gyroYoffset = y / samples;
  gyroZoffset = z / samples;
  Serial.println("Calibration Done!");
}