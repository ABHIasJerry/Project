#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>

// --- Configuration ---
#define BUTTON_PIN 14        
#define TOTAL_SCREENS 6      
#define X_OFFSET 4           // Kept your requested 4px rightward shift

// --- FIXED OLED CONSTRUCTOR FOR 1.3" SCREENS ---
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE, /* clock=*/ 22, /* data=*/ 21);

// --- Fonts ---
#define FONT_TITLE u8g2_font_7x14_tf  
#define FONT_TEXT  u8g2_font_5x8_tf   

// --- State Variables ---
int currentScreen = 0;       
volatile bool buttonPressed = false;
unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 200; 

struct DroneTelemetry {
  const char* flightMode = "ANGLE";
  bool armed = true;
  int rssi = 85;             
  float voltage = 15.8;      
  float current = 12.4;      
  int satellites = 9;
  float alt = 42.5;          
  float speed = 15.3;        
  double latitude = 37.774929;
  double longitude = -122.419418;
  int motor1 = 1420; 
  int motor2 = 1450;
  int motor3 = 1415;
  int motor4 = 1460;
  bool lowBattWarning = false;
  bool lostGpsWarning = false;
  bool imuError = false;
} drone;

void IRAM_ATTR handleButtonInterrupt() {
  unsigned long currentTime = millis();
  if ((currentTime - lastDebounceTime) > debounceDelay) {
    buttonPressed = true;
    lastDebounceTime = currentTime;
  }
}

void drawScreenNumber() {
  u8g2.setFont(FONT_TEXT);
  u8g2.setCursor(104, 10); 
  u8g2.print(currentScreen + 1);
  u8g2.print("/");
  u8g2.print(TOTAL_SCREENS);
}

void drawWelcomeScreen() {
  u8g2.clearBuffer();
  u8g2.drawFrame(0, 0, 128, 64);
  
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(24 + X_OFFSET, 25, "QUAD-OS v1.0");
  
  u8g2.setFont(FONT_TEXT);
  u8g2.drawStr(32 + X_OFFSET, 43, "SYSTEM BOOTING");
  
  for(int i = 25; i <= 100; i += 15) {
    u8g2.drawBox(25 + X_OFFSET, 48, i - 25, 3);
    u8g2.sendBuffer();
    delay(120); 
  }
}

void drawFlightStatusScreen() {
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(0 + X_OFFSET, 12, "STATUS");
  drawScreenNumber();
  u8g2.drawHLine(0, 15, 128); 
  
  u8g2.setFont(FONT_TEXT);
  u8g2.drawStr(0 + X_OFFSET, 30, "STATE :");
  u8g2.drawStr(50 + X_OFFSET, 30, drone.armed ? "ARMED" : "DISARMED");
  
  u8g2.drawStr(0 + X_OFFSET, 44, "MODE  :");
  u8g2.drawStr(50 + X_OFFSET, 44, drone.flightMode);
  
  u8g2.drawStr(0 + X_OFFSET, 58, "RSSI  :");
  u8g2.setCursor(50 + X_OFFSET, 58);
  u8g2.print(drone.rssi);
  u8g2.drawStr(75 + X_OFFSET, 58, "%");
}

void drawBatteryScreen() {
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(0 + X_OFFSET, 12, "POWER");
  drawScreenNumber();
  u8g2.drawHLine(0, 15, 128);
  
  u8g2.setFont(FONT_TEXT);
  u8g2.drawStr(0 + X_OFFSET, 30, "VOLTAGE :");
  u8g2.setCursor(65 + X_OFFSET, 30);
  u8g2.print(drone.voltage, 2);
  u8g2.drawStr(105 + X_OFFSET, 30, "V");
  
  u8g2.drawStr(0 + X_OFFSET, 44, "CURRENT :");
  u8g2.setCursor(65 + X_OFFSET, 44);
  u8g2.print(drone.current, 1);
  u8g2.drawStr(105 + X_OFFSET, 44, "A");
  
  u8g2.drawStr(0 + X_OFFSET, 58, "BATTERY :");
  int cellAvg = (drone.voltage / 4.0) * 100; 
  u8g2.setCursor(65 + X_OFFSET, 58);
  u8g2.print(constrain(map(cellAvg, 350, 420, 0, 100), 0, 100)); 
  u8g2.drawStr(105 + X_OFFSET, 58, "%");
}

void drawNavigationScreen() {
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(0 + X_OFFSET, 12, "NAV DATA");
  drawScreenNumber();
  u8g2.drawHLine(0, 15, 128);
  
  u8g2.setFont(FONT_TEXT);
  u8g2.drawStr(0 + X_OFFSET, 30, "SATELLITES :");
  u8g2.setCursor(75 + X_OFFSET, 30);
  u8g2.print(drone.satellites);
  
  u8g2.drawStr(0 + X_OFFSET, 44, "ALTITUDE   :");
  u8g2.setCursor(75 + X_OFFSET, 44);
  u8g2.print(drone.alt, 1);
  u8g2.drawStr(110 + X_OFFSET, 44, "m");
  
  u8g2.drawStr(0 + X_OFFSET, 58, "G-SPEED    :");
  u8g2.setCursor(75 + X_OFFSET, 58);
  u8g2.print(drone.speed, 1);
  u8g2.drawStr(110 + X_OFFSET, 58, "m/s");
}

void drawGpsCoordinatesScreen() {
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(0 + X_OFFSET, 12, "GPS POS");
  drawScreenNumber();
  u8g2.drawHLine(0, 15, 128);
  
  u8g2.setFont(FONT_TEXT);
  u8g2.drawStr(0 + X_OFFSET, 32, "LATITUDE :");
  u8g2.setCursor(60 + X_OFFSET, 32);
  u8g2.print(drone.latitude, 6);  
  
  u8g2.drawStr(0 + X_OFFSET, 50, "LONGITUDE:");
  u8g2.setCursor(60 + X_OFFSET, 50);
  u8g2.print(drone.longitude, 6);
}

void drawMotorSpeedsScreen() {
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(0 + X_OFFSET, 12, "MOTORS");
  drawScreenNumber();
  u8g2.drawHLine(0, 15, 128);
  
  u8g2.setFont(FONT_TEXT);
  u8g2.drawStr(0 + X_OFFSET, 32, "M1:");
  u8g2.setCursor(22 + X_OFFSET, 32);  u8g2.print(drone.motor1);

  u8g2.drawStr(64 + X_OFFSET, 32, "M2:");
  u8g2.setCursor(86 + X_OFFSET, 32); u8g2.print(drone.motor2);

  u8g2.drawStr(0 + X_OFFSET, 52, "M3:");
  u8g2.setCursor(22 + X_OFFSET, 52);  u8g2.print(drone.motor3);

  u8g2.drawStr(64 + X_OFFSET, 52, "M4:");
  u8g2.setCursor(86 + X_OFFSET, 52); u8g2.print(drone.motor4);
}

void drawWarningsScreen() {
  u8g2.setFont(FONT_TITLE);
  u8g2.drawStr(0 + X_OFFSET, 12, "WARNINGS");
  drawScreenNumber();
  u8g2.drawHLine(0, 15, 128);
  
  u8g2.setFont(FONT_TEXT);
  int activeWarnings = 0;

  if (drone.lowBattWarning) {
    u8g2.drawStr(0 + X_OFFSET, 30 + (activeWarnings * 11), "! CRITICAL LOW BATT");
    activeWarnings++;
  }
  if (drone.lostGpsWarning) {
    u8g2.drawStr(0 + X_OFFSET, 30 + (activeWarnings * 11), "! GPS GLITCH / LOST");
    activeWarnings++;
  }
  if (drone.imuError) {
    u8g2.drawStr(0 + X_OFFSET, 30 + (activeWarnings * 11), "! IMU CALIBRATION ERR");
    activeWarnings++;
  }

  if (activeWarnings == 0) {
    u8g2.drawStr(20 + X_OFFSET, 38, "ALL SYSTEMS NOMINAL");
    u8g2.drawStr(38 + X_OFFSET, 50, "NO ERRORS");
  }
}

void setup() {
  Serial.begin(115200);
  
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), handleButtonInterrupt, FALLING);
  
  u8g2.begin();
  drawWelcomeScreen();
  delay(1000); 
}

void loop() {
  if (buttonPressed) {
    buttonPressed = false;
    currentScreen = (currentScreen + 1) % TOTAL_SCREENS;
  }
  
  drone.voltage -= 0.0005; 
  drone.alt += (random(-5, 6) / 10.0);
  drone.motor1 = 1400 + random(-20, 21);
  drone.motor2 = 1400 + random(-20, 21);
  drone.motor3 = 1400 + random(-20, 21);
  drone.motor4 = 1400 + random(-20, 21);

  if (drone.voltage < 14.2) {
    drone.lowBattWarning = true;
  }

  u8g2.clearBuffer();
  
  switch (currentScreen) {
    case 0: drawFlightStatusScreen();   break;
    case 1: drawBatteryScreen();        break;
    case 2: drawNavigationScreen();     break;
    case 3: drawGpsCoordinatesScreen(); break;
    case 4: drawMotorSpeedsScreen();    break;
    case 5: drawWarningsScreen();       break;
  }
  
  u8g2.sendBuffer();
  delay(100); 
}