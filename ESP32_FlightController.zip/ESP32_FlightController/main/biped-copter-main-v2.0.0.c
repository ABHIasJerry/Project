// ========================================
// Web Configuration Access Points: Added two new hidden HTTP endpoints to turn the telemetry stream on or off instantly 
// from any device on your Wi-Fi network: http://192.168.10.1/stream/on  |  http://192.168.10.1/stream/off
// ========================================

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Update.h>
#include <esp_now.h>
#include <U8g2lib.h>
#include <TinyGPS++.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <VL53L0X.h>

// ==========================================
// 1. HARDWARE PINS & CONFIGURATION DEFINES
// ==========================================
#define BUTTON_PIN         14
#define BUZZER_PIN         25
#define ALERT_INPUT_PIN    2
#define BEACON_RED_PIN     4
#define STROBE_WHITE_PIN   23
#define RXD2               16
#define TXD2               17
#define BATTERY_ADC_PIN    34  // Added: Assigned ADC1 pin for physical voltage reading
#define GPS_BAUDRATE       9600

// I2C Addresses
#define HMC5883L_ADDR      0x1E
#define QMC5883L_ADDR      0x0D

// Biped Copter Propulsion Actuators (Brushless ESCs)
#define ACTUATOR_L_PIN     32
#define ACTUATOR_R_PIN     33

// Thrust Vectoring Servo Mechanisms
#define SERVO_L_PIN        18
#define SERVO_R_PIN        19

// Servo Calibration Constants (16-bit Duty Resolution)
#define SERVO_CENTER_DUTY  4915  // 1.5ms neutral point
#define SERVO_MAX_TRAVEL   1638  // Maximum travel allowance equivalent to +/- 45 degrees
#define MOTOR_MIN_PWM      1000
#define MOTOR_MAX_PWM      2000
#define PID_INTEGRAL_LIMIT 400  // Anti-windup clamping constraint

// ==========================================
// 2. DATA STRUCTURES & GLOBAL SUITES
// ==========================================
typedef struct struct_control_signals {
  int16_t throttle;
  int16_t yaw;
  int16_t pitch;
  int16_t roll;
  bool auxButton;
} struct_control_signals;

struct DroneState {
  float roll = 0.0, pitch = 0.0, yaw = 0.0;
  float temperature = 0.0; // Added: MPU6050 thermal reading
  float voltage = 0.0;     // Upgraded: Modified to house live analog data
  int batteryPct = 0;      // Added: Scaled capacity index
  float current = 12.4;
  
  // Magnetometer Data Store
  int16_t magX = 0, magY = 0, magZ = 0; // Added: Raw 3-axis readings
  float heading = 0.0;                  // Added: Corrected orientation angle
  
  // Speed & Course Metrics
  float speedKmh = 0.0;    // Added: Real-time ground speed tracking
  
  int rssi = 85;
  int satellites = 0;
  float alt = 0.0;
  double latitude = 0.0;
  double longitude = 0.0;
  bool armed = false;
  const char* flightMode = "STABILIZE";
  int motorL = MOTOR_MIN_PWM;
  int motorR = MOTOR_MIN_PWM;
  int servoL = SERVO_CENTER_DUTY;
  int servoR = SERVO_CENTER_DUTY;

  // Peripheral Diagnostic Trackers
  bool imuOk = false;
  bool magOk = false;
  bool tofOk = false;
} drone;

WebServer server(80);
TinyGPSPlus gps;
HardwareSerial SerialGPS(2);
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE, 22, 21);
Adafruit_MPU6050 mpu;
VL53L0X tofSensor;

volatile bool alertTriggered = false;
volatile bool screenButtonPressed = false;
unsigned long lastButtonDebounce = 0;
unsigned long lastAlertDebounce = 0;
bool isBooting = true;

// Upgraded: JSON Stream Configuration Management Variables
bool jsonStreamingActive = false; 
unsigned long lastJsonStreamTime = 0;
const unsigned long JSON_STREAM_INTERVAL_MS = 100; // Output data frequency (10Hz)

struct_control_signals incomingControl;
uint8_t controllerMacAddress[] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
esp_now_peer_info_t peerInfo;

const char* otaIndexPage = 
"<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>"
"<style>body{font-family:Arial,sans-serif;text-align:center;background:#f4f4f9;padding:50px;}"
".card{background:white;padding:30px;border-radius:10px;box-shadow:0 4px 8px rgba(0,0,0,0.1);display:inline-block;max-width:400px;width:100%;}"
"h2{color:#333;}input[type=file]{margin:20px 0;width:100%;}"
"input[type=submit]{background:#28a745;color:white;border:none;padding:10px 20px;border-radius:5px;cursor:pointer;font-size:16px;width:100%;}"
"input[type=submit]:hover{background:#218838;}</style></head>"
"<body><div class='card'><h2>ESP32 BICOPTER FOTA System</h2>"
"<p>v2.5 | Abhinaba Ghosh. Upload your new <strong>.bin</strong> firmware to flash.</p>"
"<form method='POST' action='/update' enctype='multipart/form-data'>"
"<input type='file' name='update' accept='.bin'><br>"
"<input type='submit' value='Upload & Flash'>"
"</form></div></body></html>";

const float DECLINATION_ANGLE = 0.0247;
uint8_t magAddress = 0x00;
bool isQMC = false;

TaskHandle_t Core0_TaskHandle;
TaskHandle_t Core1_TaskHandle;

float pitch_input, pitch_setpoint = 0.0, pitch_error, pitch_last_error = 0.0, pitch_integral = 0.0, pitch_derivative;
float roll_input,  roll_setpoint  = 0.0, roll_error,  roll_last_error  = 0.0, roll_integral = 0.0, roll_derivative;
float yaw_input,   yaw_setpoint   = 0.0, yaw_error,   yaw_last_error   = 0.0, yaw_integral  = 0.0, yaw_derivative;

const float Kp_pitch = 1.8, Ki_pitch = 0.02, Kd_pitch = 0.4;
const float Kp_roll  = 1.5, Ki_roll  = 0.01, Kd_roll  = 0.3;
const float Kp_yaw   = 2.2, Ki_yaw   = 0.01, Kd_yaw   = 0.5;

// ==========================================
// 3. HARDWARE ISR INTERRUPTS
// ==========================================
void IRAM_ATTR handleOledButton() {
  unsigned long t = millis();
  if (t - lastButtonDebounce > 200) {
    screenButtonPressed = true;
    lastButtonDebounce = t;
  }
}

void IRAM_ATTR handleAlertTrigger() {
  unsigned long t = millis();
  if (t - lastAlertDebounce > 250) {
    alertTriggered = true;
    lastAlertDebounce = t;
  }
}

// ==========================================
// 4. ESP-NOW COMMUNICATION CALLBACKS
// ==========================================
void OnDataRecv(const esp_now_recv_info* recvInfo, const uint8_t *incomingData, int len) {
  memcpy(&incomingControl, incomingData, sizeof(incomingControl));
  drone.armed = incomingControl.auxButton; 
  
  pitch_setpoint = map(incomingControl.pitch, 1000, 2000, -25, 25);
  roll_setpoint  = map(incomingControl.roll, 1000, 2000, -25, 25);
  yaw_setpoint   = map(incomingControl.yaw, 1000, 2000, -60, 60);
}

// ==========================================
// 5. SUBSYSTEM EXECUTIONS & HELPERS
// ==========================================
void runAudioAlerts() {
  if (!alertTriggered) return;
  alertTriggered = false;
  for (int i = 0; i < 2; i++) {
    ledcWriteTone(BUZZER_PIN, 550); delay(150);
    ledcWriteTone(BUZZER_PIN, 750); delay(150);
  }
  ledcWriteTone(BUZZER_PIN, 0);
}

void runAviationStrobes() {
  static unsigned long lastBeaconTime = 0, lastStrobeTime = 0;
  static bool beaconState = false;
  static int strobeStage = 0;
  unsigned long currentMillis = millis();

  if (currentMillis - lastBeaconTime >= 1000) {
    lastBeaconTime = currentMillis;
    beaconState = !beaconState;
    digitalWrite(BEACON_RED_PIN, beaconState ? HIGH : LOW);
  }

  switch (strobeStage) {
    case 0:
      if (currentMillis - lastStrobeTime >= 1200) {
        digitalWrite(STROBE_WHITE_PIN, HIGH);
        lastStrobeTime = currentMillis;
        strobeStage = 1;
      }
      break;
    case 1:
      if (currentMillis - lastStrobeTime >= 50) {
        digitalWrite(STROBE_WHITE_PIN, LOW);
        lastStrobeTime = currentMillis;
        strobeStage = 2;
      }
      break;
    case 2:
      if (currentMillis - lastStrobeTime >= 80) {
        digitalWrite(STROBE_WHITE_PIN, HIGH);
        lastStrobeTime = currentMillis;
        strobeStage = 3;
      }
      break;
    case 3:
      if (currentMillis - lastStrobeTime >= 50) {
        digitalWrite(STROBE_WHITE_PIN, LOW);
        lastStrobeTime = currentMillis;
        strobeStage = 0;
      }
      break;
  }
}

void initMagnetometer() {
  Wire.beginTransmission(HMC5883L_ADDR);
  if (Wire.endTransmission() == 0) {
    magAddress = HMC5883L_ADDR; isQMC = false;
    drone.magOk = true;
  } else {
    Wire.beginTransmission(QMC5883L_ADDR);
    if (Wire.endTransmission() == 0) {
      magAddress = QMC5883L_ADDR; isQMC = true;
      drone.magOk = true;
    } else {
      drone.magOk = false;
    }
  }
  if (isQMC) {
    Wire.beginTransmission(QMC5883L_ADDR); Wire.write(0x09);
    Wire.write(0x0D | 0x0C | 0x00 | 0x01); Wire.endTransmission();
  } else if (magAddress == HMC5883L_ADDR) {
    Wire.beginTransmission(HMC5883L_ADDR); Wire.write(0x02);
    Wire.write(0x00); Wire.endTransmission();
  }
}

void readMagnetometerData() {
  if (magAddress == 0x00) return;
  
  if (isQMC) {
    Wire.beginTransmission(QMC5883L_ADDR); Wire.write(0x00); Wire.endTransmission(false);
    Wire.requestFrom(QMC5883L_ADDR, 6);
    if (Wire.available() >= 6) {
      drone.magX = Wire.read() | (Wire.read() << 8);
      drone.magY = Wire.read() | (Wire.read() << 8);
      drone.magZ = Wire.read() | (Wire.read() << 8);
    }
  } else {
    Wire.beginTransmission(HMC5883L_ADDR); Wire.write(0x03); Wire.endTransmission(false);
    Wire.requestFrom(HMC5883L_ADDR, 6);
    if (Wire.available() >= 6) {
      drone.magX = (Wire.read() << 8) | Wire.read();
      drone.magZ = (Wire.read() << 8) | Wire.read();
      drone.magY = (Wire.read() << 8) | Wire.read();
    }
  }
  float heading = atan2((float)drone.magY, (float)drone.magX) + DECLINATION_ANGLE;
  if (heading < 0) heading += 2 * M_PI;
  if (heading > 2 * M_PI) heading -= 2 * M_PI;
  drone.heading = heading * 180.0 / M_PI;
}

void readBatterySensors() {
  int rawAdc = analogRead(BATTERY_ADC_PIN);
  float measuredVolt = (rawAdc / 4095.0) * 3.3 * 5.15; 
  drone.voltage = measuredVolt;
  
  if (drone.voltage >= 16.8) drone.batteryPct = 100;
  else if (drone.voltage <= 14.0) drone.batteryPct = 0;
  else drone.batteryPct = (int)((drone.voltage - 14.0) / (16.8 - 14.0) * 100.0);
}

// Upgraded: Telemetry Stream Execution Method
void setJsonStreaming(bool active) {
  jsonStreamingActive = active;
  Serial.print("{\"system_event\":\"stream_state_changed\",\"active\":");
  Serial.print(active ? "true" : "false");
  Serial.println("}");
}

// Upgraded: Base Comprehensive Serialization Engine
void streamSystemDataJSON() {
  if (!jsonStreamingActive) return;
  
  unsigned long currentMillis = millis();
  if (currentMillis - lastJsonStreamTime < JSON_STREAM_INTERVAL_MS) return;
  lastJsonStreamTime = currentMillis;

  // Manual generation of minimized JSON payload to completely bypass dynamic heap fragmentation
  Serial.print("{");
  Serial.print("\"timestamp\":"); Serial.print(currentMillis);
  Serial.print(",\"state\":{");
  Serial.print("\"armed\":"); Serial.print(drone.armed ? "true" : "false");
  Serial.print(",\"mode\":\""); Serial.print(drone.flightMode); Serial.print("\"");
  Serial.print("},\"imu\":{");
  Serial.print("\"roll\":"); Serial.print(drone.roll, 2);
  Serial.print(",\"pitch\":"); Serial.print(drone.pitch, 2);
  Serial.print(",\"yaw\":"); Serial.print(drone.yaw, 2);
  Serial.print(",\"temp\":"); Serial.print(drone.temperature, 1);
  Serial.print("},\"mag\":{");
  Serial.print("\"x\":"); Serial.print(drone.magX);
  Serial.print(",\"y\":"); Serial.print(drone.magY);
  Serial.print(",\"z\":"); Serial.print(drone.magZ);
  Serial.print(",\"heading\":"); Serial.print(drone.heading, 1);
  Serial.print("},\"gps\":{");
  Serial.print("\"sats\":"); Serial.print(drone.satellites);
  Serial.print(",\"alt\":"); Serial.print(drone.alt, 1);
  Serial.print(",\"speed\":"); Serial.print(drone.speedKmh, 1);
  Serial.print(",\"lat\":"); Serial.print(drone.latitude, 6);
  Serial.print(",\"lon\":"); Serial.print(drone.longitude, 6);
  Serial.print("},\"power\":{");
  Serial.print("\"voltage\":"); Serial.print(drone.voltage, 2);
  Serial.print(",\"pct\":"); Serial.print(drone.batteryPct);
  Serial.print(",\"current\":"); Serial.print(drone.current, 1);
  Serial.print(",\"rssi\":"); Serial.print(drone.rssi);
  Serial.print("},\"actuators\":{");
  Serial.print("\"motL\":"); Serial.print(drone.motorL);
  Serial.print(",\"motR\":"); Serial.print(drone.motorR);
  Serial.print("\"srvL\":"); Serial.print(drone.servoL);
  Serial.print(",\"srvR\":"); Serial.print(drone.servoR);
  Serial.print("},\"diagnostics\":{");
  Serial.print("\"imu_ok\":"); Serial.print(drone.imuOk ? "true" : "false");
  Serial.print(",\"mag_ok\":"); Serial.print(drone.magOk ? "true" : "false");
  Serial.print(",\"tof_ok\":"); Serial.print(drone.tofOk ? "true" : "false");
  Serial.println("}}");
}

void drawOledDisplay() {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x8_tf);
  
  if (isBooting) {
    u8g2.drawStr(15, 12, "BICOPTER SYSTEM");
    u8g2.drawStr(22, 24, "FIRMWARE v2.0.2");
    u8g2.drawStr(4, 32, "IMU MPU6050... OK");
    u8g2.drawStr(4, 42, "MAG CHIP...... OK");
    u8g2.drawStr(4, 52, "VL53L0X TOF... OK");
    u8g2.drawStr(4, 62, "NEOBlox GPS... OK");
    u8g2.sendBuffer();
    return;
  }

  static int currentScreen = 0;
  if (screenButtonPressed) {
    screenButtonPressed = false;
    currentScreen = (currentScreen + 1) % 8;
  }
  
  static float angleL = 0.0;
  static float angleR = 0.0;
  
  switch(currentScreen) {
    case 0:
      u8g2.drawStr(4, 10, "--- CONTROL INFO ---");
      u8g2.drawStr(4, 22, "Controller: ESP32 DEV38");
      u8g2.drawStr(4, 32, "Firmware  : FOTA v2.0x");
      u8g2.drawStr(4, 42, "IP Address: 192.168.10.1");
      u8g2.drawStr(4, 52, "Developer : ABHINBA GHOSH");
      u8g2.drawStr(4, 62, "Rev : 2026|v2.0.2|dev-mode");
      break;

    case 1:
      u8g2.drawStr(4, 10, "--- COPT CONFIG ---");
      u8g2.setCursor(4, 23); u8g2.print(drone.armed ? "STATE: ARMED" : "STATE: DISARMED");
      u8g2.setCursor(4, 34); u8g2.print("MODE: "); u8g2.print(drone.flightMode);
      u8g2.setCursor(4, 48); u8g2.print("MOT L/R: "); u8g2.print(drone.motorL); u8g2.print("/"); u8g2.print(drone.motorR);
      u8g2.setCursor(4, 59); u8g2.print("SRV L/R: "); u8g2.print(drone.servoL); u8g2.print("/"); u8g2.print(drone.servoR);
      break;

    case 2:
      u8g2.drawStr(4, 10, "--- GYRO-IMU STAT ---");
      u8g2.setCursor(4, 22); u8g2.print("Roll : "); u8g2.print(drone.roll, 1); u8g2.print(" deg");
      u8g2.setCursor(4, 32); u8g2.print("Pitch: "); u8g2.print(drone.pitch, 1); u8g2.print(" deg");
      u8g2.setCursor(4, 42); u8g2.print("Yaw  : "); u8g2.print(drone.yaw, 1); u8g2.print(" deg");
      u8g2.setCursor(4, 56); u8g2.print("IMU Temp: "); u8g2.print(drone.temperature, 1); u8g2.print(" C");
      break;

    case 3:
      u8g2.drawStr(4, 10, "--- NAVIGATION ---");
      u8g2.setCursor(4, 20); u8g2.print("SATS : "); u8g2.print(drone.satellites);
      u8g2.setCursor(68, 20); u8g2.print("ALT: "); u8g2.print(drone.alt, 1); u8g2.print(" m");
      u8g2.setCursor(4, 30); u8g2.print("SPEED: "); u8g2.print(drone.speedKmh, 1); u8g2.print(" km/h");
      u8g2.setCursor(4, 40); u8g2.print("AZIMUTH: "); u8g2.print(drone.heading, 1); u8g2.print(" deg");
      u8g2.setCursor(4, 50); u8g2.print("LAT  : "); u8g2.print(drone.latitude, 6);
      u8g2.setCursor(4, 60); u8g2.print("LON  : "); u8g2.print(drone.longitude, 6);
      break;

    case 4:
      u8g2.drawStr(4, 10, "--- COMPASS INFO ---");
      u8g2.setCursor(4, 22); u8g2.print("Mag X: "); u8g2.print(drone.magX);
      u8g2.setCursor(4, 32); u8g2.print("Mag Y: "); u8g2.print(drone.magY);
      u8g2.setCursor(4, 42); u8g2.print("Mag Z: "); u8g2.print(drone.magZ);
      u8g2.setCursor(4, 56); u8g2.print("Heading: "); u8g2.print(drone.heading, 1); u8g2.print(" deg");
      break;

    case 5:
      u8g2.drawStr(4, 10, "--- POWER STATS ---");
      u8g2.setCursor(4, 24); u8g2.print("Voltage: "); u8g2.print(drone.voltage, 2); u8g2.print(" V");
      u8g2.setCursor(4, 36); u8g2.print("Batt % : "); u8g2.print(drone.batteryPct); u8g2.print(" %");
      u8g2.setCursor(4, 48); u8g2.print("Current: "); u8g2.print(drone.current, 1); u8g2.print(" A");
      u8g2.setCursor(4, 58); u8g2.print("RSSI   : "); u8g2.print(drone.rssi); u8g2.print(" dBm");
      break;

    case 6:
      u8g2.drawStr(4, 10, "--- SYSTEM STATS ---");
      u8g2.setCursor(4, 22); u8g2.print("MPU6050 IMU: "); u8g2.print(drone.imuOk ? "ONLINE" : "FAULT");
      u8g2.setCursor(4, 32); u8g2.print("MAG CHIP   : "); u8g2.print(drone.magOk ? "ONLINE" : "FAULT");
      u8g2.setCursor(4, 42); u8g2.print("VL53L0X ToF: "); u8g2.print(drone.tofOk ? "ONLINE" : "FAULT");
      u8g2.setCursor(4, 52); u8g2.print("WiFi AP-STA: READY");
      u8g2.setCursor(4, 62); u8g2.print("GPS Module : "); u8g2.print(drone.satellites > 0 ? "LOCK" : "SEARCH");
      break;

    case 7:
      u8g2.drawStr(4, 10, "--- PROP STABILIZER ---");
      float speedFactorL = (drone.motorL - MOTOR_MIN_PWM) / 50.0;
      float speedFactorR = (drone.motorR - MOTOR_MIN_PWM) / 50.0;
      
      if (drone.armed && drone.motorL > 1050) angleL += speedFactorL;
      if (drone.armed && drone.motorR > 1050) angleR += speedFactorR;
      
      u8g2.drawCircle(32, 36, 16);
      float lx1 = 32 + 16 * cos(angleL * M_PI / 180.0);
      float ly1 = 36 + 16 * sin(angleL * M_PI / 180.0);
      float lx2 = 32 - 16 * cos(angleL * M_PI / 180.0);
      float ly2 = 36 - 16 * sin(angleL * M_PI / 180.0);
      u8g2.drawLine(lx1, ly1, lx2, ly2);
      
      u8g2.drawCircle(96, 36, 16);
      float rx1 = 96 + 16 * cos(angleR * M_PI / 180.0);
      float ry1 = 36 + 16 * sin(angleR * M_PI / 180.0);
      float rx2 = 96 - 16 * cos(angleR * M_PI / 180.0);
      float ry2 = 36 - 16 * sin(angleR * M_PI / 180.0);
      u8g2.drawLine(rx1, ry1, rx2, ry2);
      
      u8g2.setCursor(4, 60);  u8g2.print("L: "); u8g2.print(drone.motorL); u8g2.print("us");
      u8g2.setCursor(72, 60); u8g2.print("R: "); u8g2.print(drone.motorR); u8g2.print("us");
      break;
  }
  u8g2.sendBuffer();
}

// ==========================================
// 6. CORE 0: INTERFACE & COMMUNICATION
// ==========================================
void Core0_ExecutionLoop(void *pvParameters) {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(IPAddress(192, 168, 10, 1), IPAddress(192, 168, 10, 1), IPAddress(255, 255, 255, 0));
  WiFi.softAP("ESP32-BIPED-FC-ECU-2.0", "12345678");

  if (esp_now_init() == ESP_OK) {
    esp_now_register_recv_cb(OnDataRecv);
  }

  server.on("/", HTTP_GET, []() {
    server.sendHeader("Connection", "close");
    server.send(200, "text/html", otaIndexPage);
  });
  
  // Upgraded: Web UI Hooks for Streaming Interface Handling
  server.on("/stream/on", HTTP_GET, []() {
    setJsonStreaming(true);
    server.send(200, "application/json", "{\"status\":\"streaming_enabled\"}");
  });

  server.on("/stream/off", HTTP_GET, []() {
    setJsonStreaming(false);
    server.send(200, "application/json", "{\"status\":\"streaming_disabled\"}");
  });
  
  server.on("/update", HTTP_POST, []() {
    server.sendHeader("Connection", "close");
    server.send(200, "text/plain", (Update.hasError()) ? "Update Failed!" : "Update Success! Rebooting...");
    delay(2000);
    ESP.restart();
  }, []() {
    HTTPUpload& upload = server.upload();
    if (upload.status == UPLOAD_FILE_START) {
      if (!Update.begin(UPDATE_SIZE_UNKNOWN)) Update.printError(Serial);
    } else if (upload.status == UPLOAD_FILE_WRITE) {
      if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) Update.printError(Serial);
    } else if (upload.status == UPLOAD_FILE_END) {
      if (!Update.end(true)) Update.printError(Serial);
    }
  });

  server.begin();
  SerialGPS.begin(GPS_BAUDRATE, SERIAL_8N1, RXD2, TXD2);

  for (;;) {
    server.handleClient();
    while (SerialGPS.available() > 0) {
      gps.encode(SerialGPS.read());
    }
    if (gps.location.isValid()) {
      drone.latitude = gps.location.lat();
      drone.longitude = gps.location.lng();
      drone.satellites = gps.satellites.value();
      drone.speedKmh = gps.speed.kmph();
    }

    readBatterySensors();
    runAudioAlerts();
    runAviationStrobes();
    drawOledDisplay();
    
    // Upgraded: Safely call the streaming engine inside the asynchronous interface task stack
    streamSystemDataJSON();
    
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ==========================================
// 7. CORE 1: STABILIZATION MATRIX & SERVOS
// ==========================================
void Core1_ExecutionLoop(void *pvParameters) {
  TickType_t xLastWakeTime = xTaskGetTickCount();
  const TickType_t xFrequency = pdMS_TO_TICKS(10); 
  float dt = 0.01; 
  
  for (;;) {
    vTaskDelayUntil(&xLastWakeTime, xFrequency);

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    drone.temperature = temp.temperature;

    float gyroX = g.gyro.x * 180.0 / M_PI;
    float gyroY = g.gyro.y * 180.0 / M_PI;
    float gyroZ = g.gyro.z * 180.0 / M_PI;

    float accelRoll  = atan2(a.acceleration.y, a.acceleration.z) * 180.0 / M_PI;
    float accelPitch = atan2(-a.acceleration.x, sqrt(a.acceleration.y * a.acceleration.y + a.acceleration.z * a.acceleration.z)) * 180.0 / M_PI;

    // Complementary Filter Fusion
    drone.roll  = 0.98 * (drone.roll + gyroX * dt) + 0.02 * accelRoll;
    drone.pitch = 0.98 * (drone.pitch + gyroY * dt) + 0.02 * accelPitch;
    
    readMagnetometerData();
    drone.yaw = drone.heading;

    uint16_t distance_mm = tofSensor.readRangeContinuousMillimeters();
    if (!tofSensor.timeoutOccurred() && distance_mm <= 2000) {
      drone.alt = (float)distance_mm / 1000.0;
    }

    // --- Compute Loop PID Processing ---
    pitch_input = drone.pitch;
    pitch_error = pitch_setpoint - pitch_input;
    pitch_integral = constrain(pitch_integral + (pitch_error * dt), -PID_INTEGRAL_LIMIT, PID_INTEGRAL_LIMIT);
    pitch_derivative = (pitch_error - pitch_last_error) / dt;
    float pitch_output = (Kp_pitch * pitch_error) + (Ki_pitch * pitch_integral) + (Kd_pitch * pitch_derivative);
    pitch_last_error = pitch_error;

    roll_input = drone.roll;
    roll_error = roll_setpoint - roll_input;
    roll_integral = constrain(roll_integral + (roll_error * dt), -PID_INTEGRAL_LIMIT, PID_INTEGRAL_LIMIT);
    roll_derivative = (roll_error - roll_last_error) / dt;
    float roll_output = (Kp_roll * roll_error) + (Ki_roll * roll_integral) + (Kd_roll * roll_derivative);
    roll_last_error = roll_error;

    yaw_input = gyroZ; 
    yaw_error = yaw_setpoint - yaw_input;
    yaw_integral = constrain(yaw_integral + (yaw_error * dt), -PID_INTEGRAL_LIMIT, PID_INTEGRAL_LIMIT);
    yaw_derivative = (yaw_error - yaw_last_error) / dt;
    float yaw_output = (Kp_yaw * yaw_error) + (Ki_yaw * yaw_integral) + (Kd_yaw * yaw_derivative);
    yaw_last_error = yaw_error;

    int16_t basic_throttle = (incomingControl.throttle > MOTOR_MIN_PWM) ? incomingControl.throttle : MOTOR_MIN_PWM;

    if (drone.armed && basic_throttle > 1150) {
      drone.motorL = basic_throttle + roll_output;
      drone.motorR = basic_throttle - roll_output;

      drone.servoL = SERVO_CENTER_DUTY + pitch_output + yaw_output;
      drone.servoR = SERVO_CENTER_DUTY + pitch_output - yaw_output;

      drone.motorL = constrain(drone.motorL, MOTOR_MIN_PWM, MOTOR_MAX_PWM);
      drone.motorR = constrain(drone.motorR, MOTOR_MIN_PWM, MOTOR_MAX_PWM);
      drone.servoL = constrain(drone.servoL, SERVO_CENTER_DUTY - SERVO_MAX_TRAVEL, SERVO_CENTER_DUTY + SERVO_MAX_TRAVEL);
      drone.servoR = constrain(drone.servoR, SERVO_CENTER_DUTY - SERVO_MAX_TRAVEL, SERVO_CENTER_DUTY + SERVO_MAX_TRAVEL);
    } else {
      drone.motorL = MOTOR_MIN_PWM; drone.motorR = MOTOR_MIN_PWM;
      drone.servoL = SERVO_CENTER_DUTY; drone.servoR = SERVO_CENTER_DUTY;
      pitch_integral = 0; roll_integral = 0; yaw_integral = 0;
    }

    ledcWrite(ACTUATOR_L_PIN, map(drone.motorL, 1000, 2000, 0, 255));
    ledcWrite(ACTUATOR_R_PIN, map(drone.motorR, 1000, 2000, 0, 255));
    ledcWrite(SERVO_L_PIN, drone.servoL);
    ledcWrite(SERVO_R_PIN, drone.servoR);
  }
}

// ==========================================
// 8. STANDARD SYSTEM INITIALIZATION ENTRY
// ==========================================
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22, 400000);

  pinMode(BEACON_RED_PIN, OUTPUT);
  pinMode(STROBE_WHITE_PIN, OUTPUT);
  pinMode(ALERT_INPUT_PIN, INPUT_PULLUP);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  analogSetAttenuation(ADC_11db);
  
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), handleOledButton, FALLING);
  attachInterrupt(digitalPinToInterrupt(ALERT_INPUT_PIN), handleAlertTrigger, FALLING);

  ledcAttachChannel(BUZZER_PIN, 1000, 8, 0);
  ledcAttachChannel(ACTUATOR_L_PIN, 50, 8, 1);
  ledcAttachChannel(ACTUATOR_R_PIN, 50, 8, 2);
  ledcAttachChannel(SERVO_L_PIN, 50, 16, 3);
  ledcAttachChannel(SERVO_R_PIN, 50, 16, 4);

  u8g2.begin();
  
  drone.imuOk = mpu.begin();
  initMagnetometer();
  
  tofSensor.setBus(&Wire);
  if (tofSensor.init()) {
    drone.tofOk = true;
    tofSensor.setMeasurementTimingBudget(20000);
    tofSensor.startContinuous();
  } else {
    drone.tofOk = false;
  }

  drawOledDisplay();
  delay(3000); 
  isBooting = false; 

  xTaskCreatePinnedToCore(Core0_ExecutionLoop, "Core0_System", 8192, NULL, 1, &Core0_TaskHandle, 0);
  xTaskCreatePinnedToCore(Core1_ExecutionLoop, "Core1_Flight",  8192, NULL, 3, &Core1_TaskHandle, 1);
}

// ==========================================
// 9. STANDARD SYSTEM LOOP
// ==========================================
void loop() {}