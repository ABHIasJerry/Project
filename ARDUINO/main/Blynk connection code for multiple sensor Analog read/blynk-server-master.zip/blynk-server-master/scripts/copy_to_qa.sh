#!/bin/sh

scp ../server/launcher/target/server-0.41.12-SNAPSHOT.jar root@warmboard.blynk.cc:/root