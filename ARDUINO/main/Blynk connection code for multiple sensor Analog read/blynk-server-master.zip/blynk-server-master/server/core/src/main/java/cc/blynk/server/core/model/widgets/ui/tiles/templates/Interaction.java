package cc.blynk.server.core.model.widgets.ui.tiles.templates;

public enum Interaction {

    BUTTON, PAGE, STEP

}
