package cc.blynk.server.core.model.widgets.outputs.graph;

public enum YAxisScale {

    UNSET,
    AUTO,
    MINMAX,
    HEIGHT,
    DELTA

}
