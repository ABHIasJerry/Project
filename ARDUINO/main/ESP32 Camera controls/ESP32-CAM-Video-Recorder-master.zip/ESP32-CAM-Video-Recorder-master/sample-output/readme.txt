
... moved to https://github.com/jameszah/ESP32-CAM-Video-Recorder-samples

Filenames show date and time at beginning of recording, plus framesize, quality, interval (ms), length(s), and playback speed.
